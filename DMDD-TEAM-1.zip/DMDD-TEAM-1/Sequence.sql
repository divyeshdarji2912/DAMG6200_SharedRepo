set serveroutput on;
--For incrementing values for Landlord_ID
create sequence seq_landlord_id start with 1;

--For incrementing values for Apartment_ID
create sequence seq_apartment_id start with 1;

--For incrementing values for Apartment_Type_ID
create sequence seq_apartment_type_id start with 1;